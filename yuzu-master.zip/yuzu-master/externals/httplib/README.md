From https://github.com/yhirose/cpp-httplib/tree/fce8e6fefdab4ad48bc5b25c98e5ebfda4f3cf53

MIT License

===

cpp-httplib

A C++11 header-only HTTP library.

It's extremely easy to setup. Just include httplib.h file in your code!

Inspired by Sinatra and express.

© 2017 Yuji Hirose
